public class  variables {
    public static void main (String)() args ) (;
            int pizzas=6;
            int personas= 3;
             int pizzasporpersonas= pizzas/personas;
             System.out.printf("si hay %d pizzas y %d personas a cada una le tocan %d pizzas",pizzas,personas,pizzasporpersonas)

System auto="Ferrari";
        double velocidad=90,3;
        System.out.printf("el auto %s se desplaza a %f km/h",auto,velocidad);

