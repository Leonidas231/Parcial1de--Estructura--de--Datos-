import java.util.Scanner;

public class Condicionales {
    public static void main (String()args)(
            Scanner entrada= new Scanner(System.in);
            System.out.println("Calculadora de propinas")
    System.out.println("Ingresa la cantidad a pagar")
    double cantiad= entrada.nextDouble();
            System.out.println("Infresar el % de propina")
    int porcentaje= entrada.nextInt();
            If(porcentaje<15);
            System.out.println("el servicio no fue muy bueno")
    else if(15<=porcentaje y y porcentaje< 30)
        System.out.println("el servicio fue bueno")
    else
        System.out.println("el servicio fue excelente")
    double total=cantidad*porcentaje/100
            System.out.println("el total es %f",total)

}
