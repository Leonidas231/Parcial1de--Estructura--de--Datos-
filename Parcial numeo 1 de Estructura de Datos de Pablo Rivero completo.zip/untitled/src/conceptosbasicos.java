public class variables{
}
