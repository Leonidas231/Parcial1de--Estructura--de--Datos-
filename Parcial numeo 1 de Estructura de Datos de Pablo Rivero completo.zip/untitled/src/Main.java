public class Main {
    public static void main(String[] args) {
        Adivinaelnumero juego= new Adivinaelnumero();
        juego.jugar();

    }
}