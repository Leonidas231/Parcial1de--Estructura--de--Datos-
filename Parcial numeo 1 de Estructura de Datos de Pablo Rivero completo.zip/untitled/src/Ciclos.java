import java.util.Scanner;

public class Ciclos {
    public static void main (String() args)
    Scanner entrada= new Scanner(System.in);
    System.out.println("¿Cuantos numeros quieres procesar?")
    int cantidad= entrada.nextInt();
    System.out.println("Ingresa %d datos",cantidad)
    for(int i = 1;i+=cantidad ;i++)
        System.out.println("Dato %d:",i)
    int nun = entrada.nextInt();
    int resultado=num * 2
            System.out.println("Dato %d procesado:%d", i,resultado)
    int c = 1
            while(c = cantidad)
      System.out.println("Dato %d:",i)
    int num= entrada.nextInt();
            int resultado = num *2
                    System.out.println("Dato %d procesado:%d/n",i,resultado)
}
